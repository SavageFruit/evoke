var gIDs = {
  "google.com": "google.id",
  "duckduckgo.com": "ddg.id"
}

console.log(gIDs.duckduckgo)
